=== Mahjong Deluxe ===
Tags: board game, card, cards, html5 mahjong, mahjong, mobile, puzzle, tile,logic, solitaire, solitaire game, chinese game, card game,html5 solitaire, html5 board game
Requires at least: 4.3
Tested up to: 4.3

Add Mahjong Deluxe to CTL Arcade plugin

== Description ==
Add Mahjong Deluxe to CTL Arcade plugin


	